import { OpinionFeed } from "@/components/OpinionFeed"

const Index = () => {
  return <OpinionFeed />
};

export default Index;
